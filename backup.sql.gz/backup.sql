-- MySQL dump 10.13  Distrib 8.0.42, for macos15.2 (arm64)
--
-- Host: 192.168.0.130    Database: reportesv2
-- ------------------------------------------------------
-- Server version	11.7.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ampacities`
--

DROP TABLE IF EXISTS `ampacities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ampacities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `size` varchar(11) DEFAULT NULL,
  `ampacity` int(11) DEFAULT NULL,
  `temperature` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ampacities`
--

LOCK TABLES `ampacities` WRITE;
/*!40000 ALTER TABLE `ampacities` DISABLE KEYS */;
INSERT INTO `ampacities` VALUES (1,'22 AWG',9,150),(2,'20 AWG',13,150),(3,'18 AWG',17,150),(4,'16 AWG',22,150),(5,'14 AWG',34,150),(6,'12 AWG',43,150),(7,'10 AWG',55,150),(8,'8 AWG',76,150),(9,'6 AWG',96,150),(10,'4 AWG',120,150),(11,'2 AWG',160,150),(12,'1 AWG',186,150),(13,'1/0 AWG',215,150),(14,'2/0 AWG',251,150),(15,'3/0 AWG',288,150),(16,'4/0 AWG',332,150),(17,'250mcm',386,150),(18,'300mcm',426,150),(19,'350mcm',466,150),(20,'22 AWG',10,200),(21,'20 AWG',15,200),(22,'18 AWG',20,200),(23,'16 AWG',25,200),(24,'14 AWG',36,200),(25,'12 AWG',45,200),(26,'10 AWG',60,200),(27,'8 AWG',83,200),(28,'6 AWG',110,200),(29,'4 AWG',125,200),(30,'2 AWG',171,200),(31,'1 AWG',197,200),(32,'1/0 AWG',229,200),(33,'2/0 AWG',260,200),(34,'3/0 AWG',297,200),(35,'4/0 AWG',346,200);
/*!40000 ALTER TABLE `ampacities` ENABLE KEYS */;
UNLOCK TABLES;
